package com.autotesting.framework.screens;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class MainPageScreen {	
    private static ChromeDriverService service;
    private static WebDriver driver;
    
    private static final String PATH_TO_CHROMEDRIVER = "resource//chromedriver.exe";
    private static final String OPEN_MAIL_XPATH = "//*[@id='mainmenu']/div/ul[1]/li[2]/a";
    private static final String LOGIN = "adminkat1@tut.by";
    private static final String EMPTY_LOGIN = "";
    private static final String LOGIN_FIELD_XPATH = "//*[@id='Username']";
    private static final String PASSWORD = "1qaz1qaz";
    private static final String PASSWORD_FIELD_XPATH = "//*[@id='Password']";
    private static final String ENTER_BUTTON_XPATH = "//*[@id='form']/fieldset/div[3]/input";
    private static final String INVALID_LOGIN = "adminkatt1@tut.by";
    private static final String INVALID_PASSWORD = "1qaz2wsx";
    private static final String RESTORE_PASSWORD_LINK_XPASS = "//*[@id='form']/fieldset/div[2]/a";
    private static final String LOGIN_ERROR_MESSAGE_PATH = "//*[@id=form]/fieldset/strong";
    private static final String EXPECTED_LOGIN_ERROR_MESSAGE = "Неверное имя пользователя или пароль";
    private static final String EXPECTED_MESSAGE_TEXT_XPATH = "//*[@id='form']/fieldset/strong";
    private static final String EXPECTED_MESSAGE_TEXT = "Восстановить забытый пароль »";
    
  
    @BeforeClass
    public static void createAndStartService() throws IOException {
    	service = new ChromeDriverService.Builder()
    		.usingChromeDriverExecutable(new File(PATH_TO_CHROMEDRIVER))
    		.usingAnyFreePort()
    		.build();
        service.start();
        
    }

    @Test
    public void assertMessage() throws InterruptedException {    
    	driver = new ChromeDriver(service);
        driver.get("http://www.tut.by");
        driver.findElement(By.xpath(OPEN_MAIL_XPATH)).click();
        Assert.assertEquals(driver.findElement(By.xpath(EXPECTED_MESSAGE_TEXT_XPATH)).getText(),
                EXPECTED_MESSAGE_TEXT);
        driver.close();
    }
    
    @Test
    public void validLoginToMail() throws InterruptedException {    
    	driver = new ChromeDriver(service);
        driver.get("http://www.tut.by");
        driver.findElement(By.xpath(OPEN_MAIL_XPATH)).click();
        driver.findElement(By.xpath(LOGIN_FIELD_XPATH)).sendKeys(LOGIN);
        driver.findElement(By.xpath(PASSWORD_FIELD_XPATH)).sendKeys(PASSWORD);
        driver.findElement(By.xpath(ENTER_BUTTON_XPATH)).click();
        driver.close();
    } 
    
    @Test
    public void invalidLoginNameToMail() throws InterruptedException {     
    	driver = new ChromeDriver(service);
        driver.get("http://www.tut.by");
        driver.findElement(By.xpath(OPEN_MAIL_XPATH)).click();
        driver.findElement(By.xpath(LOGIN_FIELD_XPATH)).sendKeys(INVALID_LOGIN);
        driver.findElement(By.xpath(PASSWORD_FIELD_XPATH)).sendKeys(PASSWORD);
        driver.findElement(By.xpath(ENTER_BUTTON_XPATH)).click();
        driver.close();
    }
    
    @Test
    public void invalidPasswordToMail() throws InterruptedException {     
    	driver = new ChromeDriver(service);
        driver.get("http://www.tut.by");
        driver.findElement(By.xpath(OPEN_MAIL_XPATH)).click();
        driver.findElement(By.xpath(LOGIN_FIELD_XPATH)).sendKeys(LOGIN);
        driver.findElement(By.xpath(PASSWORD_FIELD_XPATH)).sendKeys(INVALID_PASSWORD);
        driver.findElement(By.xpath(ENTER_BUTTON_XPATH)).click();
        driver.close();
    }
    
    @Test
    public void invalidLoginAndPasswordToMail() throws InterruptedException { 
    	driver = new ChromeDriver(service);
        driver.get("http://www.tut.by");
        driver.findElement(By.xpath(OPEN_MAIL_XPATH)).click();
        driver.findElement(By.xpath(LOGIN_FIELD_XPATH)).sendKeys(INVALID_LOGIN);
        driver.findElement(By.xpath(PASSWORD_FIELD_XPATH)).sendKeys(INVALID_PASSWORD);
        driver.findElement(By.xpath(ENTER_BUTTON_XPATH)).click();
        driver.close();
    }
    
    @Test
    public void verifyInvalidLoginErrorMessage() throws InterruptedException {    
        driver.get("http://www.tut.by/");
        driver.findElement(By.xpath(OPEN_MAIL_XPATH)).click();
        driver.findElement(By.xpath(LOGIN_FIELD_XPATH)).sendKeys(INVALID_LOGIN);
        driver.findElement(By.xpath(PASSWORD_FIELD_XPATH)).sendKeys(INVALID_PASSWORD);
        driver.findElement(By.xpath(ENTER_BUTTON_XPATH)).click();
        Assert.assertEquals(driver.findElement(By.xpath(LOGIN_ERROR_MESSAGE_PATH)).getText(),
                EXPECTED_LOGIN_ERROR_MESSAGE);

    }
    
    @Test
    public void restorePassword() throws InterruptedException {   
    	driver = new ChromeDriver(service);
        driver.get("http://www.tut.by");
        driver.findElement(By.xpath(RESTORE_PASSWORD_LINK_XPASS)).click();
        driver.close();
    }
    
    @Test
    public void emptyLoginToMail() throws InterruptedException { 
    	driver = new ChromeDriver(service);
        driver.get("http://www.tut.by");
        driver.findElement(By.xpath(OPEN_MAIL_XPATH)).click();
        driver.findElement(By.xpath(LOGIN_FIELD_XPATH)).sendKeys(EMPTY_LOGIN);
        driver.findElement(By.xpath(PASSWORD_FIELD_XPATH)).sendKeys(PASSWORD);
        driver.findElement(By.xpath(ENTER_BUTTON_XPATH)).click();
        driver.close();
    }
    


    @AfterClass
    public static void createAndStopService() {
    	driver.quit();
        service.stop();
    }
}
