package com.autotesting.framework.suits;

import org.testng.annotations.Test;

import com.autotesting.framework.screens.MainPageScreen;

public class invalidLoginName {

	@Test
	public void invalidLoginNameToMail() {
		MainPageScreen mainPage = new MainPageScreen();
	}

}
