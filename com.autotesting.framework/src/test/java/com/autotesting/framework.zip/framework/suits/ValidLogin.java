package com.autotesting.framework.suits;

import org.testng.annotations.Test;

import com.autotesting.framework.screens.MainPageScreen;

public class ValidLogin {

	@Test
	public void validLoginToMail(){
	 MainPageScreen mainPage = new MainPageScreen();
 }
 
}